// Simple i18n with JSON translations. Auto-detect + localStorage + dropdown.
// Language preference persists across all pages and browser tabs.

let translations = {};
let currentLang = "en";

// Get saved language immediately (before DOM is ready)
function getSavedLanguage() {
  try {
    const saved = localStorage.getItem("language");
    if (
      saved &&
      (saved === "en" || saved === "es" || saved === "fr" || saved === "de")
    ) {
      return saved;
    }
  } catch (e) {
    console.warn("localStorage not available:", e);
  }
  // Fallback to browser language or default
  try {
    const nav = navigator.language || navigator.userLanguage || "en";
    const code = nav.slice(0, 2).toLowerCase();
    return code === "en" || code === "es" || code === "fr" || code === "de"
      ? code
      : "en";
  } catch (e) {
    return "en";
  }
}

// Set initial language as early as possible
currentLang = getSavedLanguage();
if (document.documentElement) {
  document.documentElement.lang = currentLang;
}

async function loadTranslations() {
  try {
    const res = await fetch("translations.json");
    if (!res.ok) throw new Error("Could not load translations: " + res.status);
    translations = await res.json();
  } catch (err) {
    console.error("Error loading translations:", err);
    translations = {}; // fallback empty
    return; // Don't proceed if translations failed to load
  }

  // Now that translations are loaded, detect and apply language
  detectLanguage();
  applyTranslations();
}

function detectLanguage() {
  // First, try to get saved language from localStorage
  const saved = localStorage.getItem("language");

  if (
    saved &&
    (saved === "en" || saved === "es" || saved === "fr" || saved === "de")
  ) {
    // Use saved language if it's valid
    if (translations && translations[saved]) {
      currentLang = saved;
    } else {
      // Translations not loaded yet, but use saved preference anyway
      currentLang = saved;
    }
  } else {
    // No saved preference, detect from browser
    const nav = navigator.language || navigator.userLanguage || "en";
    const code = nav.slice(0, 2).toLowerCase();
    const detectedLang =
      code === "en" || code === "es" || code === "fr" || code === "de"
        ? code
        : "en";

    if (translations && translations[detectedLang]) {
      currentLang = detectedLang;
    } else {
      currentLang = "en"; // fallback
    }

    // Save the detected language
    localStorage.setItem("language", currentLang);
  }

  // Update selector
  const sel = document.getElementById("languageSwitcher");
  if (sel) sel.value = currentLang;
}

function applyTranslations() {
  // set lang attribute on html
  try {
    document.documentElement.lang = currentLang;
  } catch (e) {}

  // Check if translations are loaded
  if (!translations || Object.keys(translations).length === 0) {
    console.warn("Translations not loaded yet");
    return;
  }

  if (!translations[currentLang]) {
    console.warn("Translations not available for language:", currentLang);
    return;
  }

  let appliedCount = 0;
  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.getAttribute("data-i18n");
    if (!key) return;
    const txt = lookupKey(currentLang, key);
    if (txt !== null && txt !== undefined) {
      appliedCount++;
      // for titles use textContent; for <title> we update document.title
      if (el.tagName.toLowerCase() === "title") {
        document.title = txt;
      } else {
        // Check if translation contains newlines (for addresses, etc.)
        // If so, convert newlines to <br /> tags
        if (txt.includes("\n")) {
          el.innerHTML = txt.replace(/\n/g, "<br />");
        } else {
          // Use textContent for regular text (safest approach)
          el.textContent = txt;
        }
      }
    }
  });

  if (appliedCount === 0) {
    console.warn(
      "No translations were applied. Check if data-i18n attributes match translation keys."
    );
  }
}

function lookupKey(lang, key) {
  // key can be nested via dots: "nav.home" etc.
  const parts = key.split(".");
  let obj = translations[lang];
  for (let p of parts) {
    if (!obj || typeof obj !== "object" || !(p in obj)) return null;
    obj = obj[p];
  }
  return typeof obj === "string" ? obj : null;
}

function changeLanguage(newLang) {
  if (!translations || !translations[newLang]) {
    console.warn("Language not available or translations not loaded:", newLang);
    // If translations aren't loaded yet, save the preference and reload
    if (!translations || Object.keys(translations).length === 0) {
      localStorage.setItem("language", newLang);
      currentLang = newLang;
      loadTranslations();
      return;
    }
    return;
  }
  currentLang = newLang;
  localStorage.setItem("language", currentLang);

  // Update selector first
  const sel = document.getElementById("languageSwitcher");
  if (sel) sel.value = currentLang;

  // Then apply translations
  applyTranslations();
}

// Listen for storage changes (sync across tabs/windows)
window.addEventListener("storage", (e) => {
  if (e.key === "language" && e.newValue && translations[e.newValue]) {
    currentLang = e.newValue;
    applyTranslations();
    const sel = document.getElementById("languageSwitcher");
    if (sel) sel.value = currentLang;
  }
});

// Listen for page visibility changes (re-apply translations if needed)
document.addEventListener("visibilitychange", () => {
  if (!document.hidden) {
    const saved = localStorage.getItem("language");
    if (saved && saved !== currentLang && translations[saved]) {
      currentLang = saved;
      applyTranslations();
      const sel = document.getElementById("languageSwitcher");
      if (sel) sel.value = currentLang;
    }
  }
});

// Function to initialize everything
function init() {
  // Ensure we have the latest saved language
  const saved = localStorage.getItem("language");
  if (
    saved &&
    (saved === "en" || saved === "es" || saved === "fr" || saved === "de")
  ) {
    currentLang = saved;
  }

  const switcher = document.getElementById("languageSwitcher");
  if (switcher) {
    switcher.addEventListener("change", (e) => {
      changeLanguage(e.target.value);
    });
  }
  loadTranslations();
}

document.addEventListener("DOMContentLoaded", init);

// Also run on page load (in case DOMContentLoaded already fired)
if (document.readyState === "loading") {
  // DOMContentLoaded has not fired yet - wait for it
} else {
  // DOMContentLoaded has already fired - run immediately
  init();
}
